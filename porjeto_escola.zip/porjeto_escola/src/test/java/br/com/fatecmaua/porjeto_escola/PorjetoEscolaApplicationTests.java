package br.com.fatecmaua.porjeto_escola;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PorjetoEscolaApplicationTests {

	@Test
	void contextLoads() {
	}

}
